-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 20, 2016 at 04:42 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ci3ng`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_audit`
--

CREATE TABLE `tbl_audit` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `action` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `information` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ip_address` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `params` text COLLATE utf8_unicode_ci,
  `uuid` char(36) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `application_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `added_at` datetime DEFAULT NULL,
  `added_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edited_at` datetime DEFAULT NULL,
  `edited_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `version` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_lookup`
--

CREATE TABLE `tbl_lookup` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `code` int(11) NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `position` int(10) UNSIGNED DEFAULT NULL,
  `uuid` char(36) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `application_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `added_at` datetime DEFAULT NULL,
  `added_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edited_at` datetime DEFAULT NULL,
  `edited_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `version` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_permission`
--

CREATE TABLE `tbl_permission` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uuid` char(36) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `application_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `added_at` datetime DEFAULT NULL,
  `added_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edited_at` datetime DEFAULT NULL,
  `edited_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `version` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_permission`
--

INSERT INTO `tbl_permission` (`id`, `name`, `description`, `uuid`, `application_key`, `added_at`, `added_by`, `edited_at`, `edited_by`, `is_deleted`, `version`) VALUES
(1, 'Backend.Account', 'Allows you to manage users, roles and permissions.', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-12-20 13:40:24', NULL, '2016-12-20 13:40:24', NULL, 0, 1),
(2, 'Backend.Account.Permission', 'Allows you to manage permissions.', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-12-20 13:40:24', NULL, '2016-12-20 13:40:24', NULL, 0, 1),
(3, 'Backend.Account.Role', 'Allows you to manage roles.', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-12-20 13:40:24', NULL, '2016-12-20 13:40:24', NULL, 0, 1),
(4, 'Backend.Account.User', 'Allows you to manage users.', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-12-20 13:40:24', NULL, '2016-12-20 13:40:24', NULL, 0, 1),
(5, 'Backend.System', 'Allows you to manage audit trails, lookup values and settings.', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-12-20 13:40:24', NULL, '2016-12-20 13:40:24', NULL, 0, 1),
(6, 'Backend.System.Audit', 'Allows you to manage audit trails.', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-12-20 13:40:24', NULL, '2016-12-20 13:40:24', NULL, 0, 1),
(7, 'Backend.System.Lookup', 'Allows you to manage lookup values.', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-12-20 13:40:24', NULL, '2016-12-20 13:40:24', NULL, 0, 1),
(8, 'Backend.System.Setting', 'Allows you to manage settings.', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-12-20 13:40:24', NULL, '2016-12-20 13:40:24', NULL, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_role`
--

CREATE TABLE `tbl_role` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uuid` char(36) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `application_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `added_at` datetime DEFAULT NULL,
  `added_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edited_at` datetime DEFAULT NULL,
  `edited_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `version` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_role`
--

INSERT INTO `tbl_role` (`id`, `name`, `description`, `uuid`, `application_key`, `added_at`, `added_by`, `edited_at`, `edited_by`, `is_deleted`, `version`) VALUES
(1, 'Administrator', 'Members of the Administrator role have the largest amount of default permissions and the ability to change their own permissions.', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-12-20 13:40:24', NULL, '2016-12-20 13:40:24', NULL, 0, 1),
(2, 'Guest', NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-12-20 13:40:24', NULL, '2016-12-20 13:40:24', NULL, 0, 1),
(3, 'Power User', NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-12-20 13:40:24', NULL, '2016-12-20 13:40:24', NULL, 0, 1),
(4, 'User', NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-12-20 13:40:24', NULL, '2016-12-20 13:40:24', NULL, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_role_permission`
--

CREATE TABLE `tbl_role_permission` (
  `role_id` int(10) UNSIGNED NOT NULL,
  `permission_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_role_permission`
--

INSERT INTO `tbl_role_permission` (`role_id`, `permission_id`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(1, 5),
(1, 6),
(1, 7),
(1, 8),
(3, 1),
(3, 4),
(3, 5),
(3, 6),
(3, 8);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_setting`
--

CREATE TABLE `tbl_setting` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uuid` char(36) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `application_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `added_at` datetime DEFAULT NULL,
  `added_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edited_at` datetime DEFAULT NULL,
  `edited_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `version` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_setting`
--

INSERT INTO `tbl_setting` (`id`, `name`, `value`, `description`, `uuid`, `application_key`, `added_at`, `added_by`, `edited_at`, `edited_by`, `is_deleted`, `version`) VALUES
(1, 'copyright', 'Copyright (c) 2016 ntd1712', NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-12-20 13:40:24', NULL, '2016-12-20 13:40:24', NULL, 0, 1),
(2, 'title', 'Admin Panel', NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-12-20 13:40:24', NULL, '2016-12-20 13:40:24', NULL, 0, 1),
(3, 'defaultRoute', 'setting.index', NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-12-20 13:40:24', NULL, '2016-12-20 13:40:24', NULL, 0, 1),
(4, 'imageAllowedExt', 'gif,jpeg,jpg,png', NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-12-20 13:40:24', NULL, '2016-12-20 13:40:24', NULL, 0, 1),
(5, 'imageMaxSize', '2097152', NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-12-20 13:40:24', NULL, '2016-12-20 13:40:24', NULL, 0, 1),
(6, 'dateFormat', 'Y-m-d', NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-12-20 13:40:24', NULL, '2016-12-20 13:40:24', NULL, 0, 1),
(7, 'timeFormat', 'H:i:s', NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-12-20 13:40:24', NULL, '2016-12-20 13:40:24', NULL, 0, 1),
(8, 'itemsPerPage', '10', NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-12-20 13:40:24', NULL, '2016-12-20 13:40:24', NULL, 0, 1),
(9, 'maxItemsPerPage', '100', NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-12-20 13:40:24', NULL, '2016-12-20 13:40:24', NULL, 0, 1),
(10, 'minSearchChars', '4', NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-12-20 13:40:24', NULL, '2016-12-20 13:40:24', NULL, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_staff`
--

CREATE TABLE `tbl_staff` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `uuid` char(36) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `application_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `added_at` datetime DEFAULT NULL,
  `added_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edited_at` datetime DEFAULT NULL,
  `edited_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `version` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_expiry_date` datetime DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `open_id` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locale` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `timezone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `profile` text COLLATE utf8_unicode_ci COMMENT '(DC2Type:json_array)',
  `uuid` char(36) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `application_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `added_at` datetime DEFAULT NULL,
  `added_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edited_at` datetime DEFAULT NULL,
  `edited_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `version` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `password`, `password_expiry_date`, `remember_token`, `open_id`, `locale`, `timezone`, `profile`, `uuid`, `application_key`, `added_at`, `added_by`, `edited_at`, `edited_by`, `is_deleted`, `version`) VALUES
(1, 'sysadmin', 'sysadmin@example.com', '$2y$10$h5srPVTh.pxL7XKHcPQBuu32mojHIfN0nxcUtCMHoXtPtOmFNO.MS', NULL, 'w4PGczRECl', NULL, NULL, NULL, '{"DisplayName":"Fiona Tromp","Photo":"\\/uploads\\/no_photo.jpg","About":"Exercitationem eaque ad voluptas minus dicta cumque veritatis. Accusantium totam est fuga optio. Temporibus facere et itaque veritatis consequatur."}', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-12-20 13:40:24', NULL, '2016-12-20 13:40:24', NULL, 0, 1),
(2, 'demo', 'demo@example.com', '$2y$10$Du4kxbMCbKkZ53UU.AKGneVYg556Cl.cfRogLjOwWCj9VAUR8GVLa', NULL, 'VuR2actjtF', NULL, NULL, NULL, '{"DisplayName":"Ms. Heaven Cruickshank IV","Photo":"\\/uploads\\/no_photo.jpg","About":"Illum voluptatum error doloremque et minus aut. Commodi placeat perferendis perferendis expedita. Quia ut molestiae at autem."}', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-12-20 13:40:24', NULL, '2016-12-20 13:40:24', NULL, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_role`
--

CREATE TABLE `tbl_user_role` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `is_primary` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_user_role`
--

INSERT INTO `tbl_user_role` (`user_id`, `role_id`, `is_primary`) VALUES
(1, 1, 1),
(2, 3, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_audit`
--
ALTER TABLE `tbl_audit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_lookup`
--
ALTER TABLE `tbl_lookup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_permission`
--
ALTER TABLE `tbl_permission`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_role`
--
ALTER TABLE `tbl_role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_role_permission`
--
ALTER TABLE `tbl_role_permission`
  ADD PRIMARY KEY (`role_id`,`permission_id`),
  ADD KEY `IDX_B151AD08D60322AC` (`role_id`),
  ADD KEY `IDX_B151AD08FED90CCA` (`permission_id`);

--
-- Indexes for table `tbl_setting`
--
ALTER TABLE `tbl_setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_staff`
--
ALTER TABLE `tbl_staff`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user_role`
--
ALTER TABLE `tbl_user_role`
  ADD PRIMARY KEY (`user_id`,`role_id`),
  ADD KEY `IDX_6860A930A76ED395` (`user_id`),
  ADD KEY `IDX_6860A930D60322AC` (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_audit`
--
ALTER TABLE `tbl_audit`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_lookup`
--
ALTER TABLE `tbl_lookup`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_permission`
--
ALTER TABLE `tbl_permission`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_role`
--
ALTER TABLE `tbl_role`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_setting`
--
ALTER TABLE `tbl_setting`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `tbl_staff`
--
ALTER TABLE `tbl_staff`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_role_permission`
--
ALTER TABLE `tbl_role_permission`
  ADD CONSTRAINT `FK_B151AD08D60322AC` FOREIGN KEY (`role_id`) REFERENCES `tbl_role` (`id`),
  ADD CONSTRAINT `FK_B151AD08FED90CCA` FOREIGN KEY (`permission_id`) REFERENCES `tbl_permission` (`id`);

--
-- Constraints for table `tbl_user_role`
--
ALTER TABLE `tbl_user_role`
  ADD CONSTRAINT `FK_6860A930A76ED395` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`id`),
  ADD CONSTRAINT `FK_6860A930D60322AC` FOREIGN KEY (`role_id`) REFERENCES `tbl_role` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
